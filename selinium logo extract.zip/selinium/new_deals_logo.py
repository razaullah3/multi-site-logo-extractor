import time
import base64
import pandas as pd
import logging
from urllib.parse import urljoin
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# --- SETTINGS ---
INPUT_FILE = r"E:\web scraping data\deals_logo.xlsx"
OUTPUT_FILE = "razi_logo_advanced.csv"
HEADLESS_MODE = True  # Background mein chalane ke liye

# Logging setup (Progress dekhne ke liye)
logging.basicConfig(level=logging.INFO, format='%(message)s')

def get_driver():
    options = Options()
    if HEADLESS_MODE:
        options.add_argument("--headless")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-notifications")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    return driver

def extract_svg_as_base64(element):
    """SVG tag ko text/base64 format mein convert karta hai"""
    try:
        svg_code = element.get_attribute('outerHTML')
        encoded = base64.b64encode(svg_code.encode('utf-8')).decode('utf-8')
        return f"data:image/svg+xml;base64,{encoded}"
    except:
        return None

def find_logo(driver, url):
    reason = "Logo not found"
    try:
        driver.get(url)
        # Lazy loading handle karne ke liye thora scroll
        driver.execute_script("window.scrollTo(0, 300);")
        time.sleep(3) 

        # 1. Check for <img> tags (Common patterns)
        selectors = [
            "header img[alt*='logo' i]", "img[src*='logo' i]", 
            "a[class*='logo' i] img", ".header-logo img", "header img"
        ]
        for s in selectors:
            try:
                el = driver.find_element(By.CSS_SELECTOR, s)
                src = el.get_attribute("src")
                if src: return urljoin(url, src), "Found via Image Tag"
            except: continue

        # 2. Check for <svg> tags
        try:
            svg_el = driver.find_element(By.CSS_SELECTOR, "header svg, .logo svg, a[class*='logo' i] svg")
            if svg_el:
                return extract_svg_as_base64(svg_el), "Found via SVG Tag"
        except: pass

        # 3. Check for CSS Background Image
        try:
            logo_div = driver.find_element(By.CSS_SELECTOR, ".logo, #logo, .header-logo")
            bg = logo_div.value_of_css_property("background-image")
            if "url(" in bg:
                clean_url = bg.split('"')[1] if '"' in bg else bg.split('(')[1].split(')')[0]
                return urljoin(url, clean_url), "Found via CSS Background"
        except: pass

        reason = "No <img>, <svg> or CSS background detected"
    except Exception as e:
        reason = f"Error/Timeout: {str(e)[:50]}"
    
    return "URL not found", reason

# --- MAIN EXECUTION ---
def main():
    try:
        df = pd.read_excel(INPUT_FILE, header=None)
        urls = df[0].dropna().unique().tolist()
    except Exception as e:
        print(f"File parhne mein masla: {e}")
        return

    driver = get_driver()
    final_data = []

    print(f"🚀 Scraping shuru... Total URLs: {len(urls)}")

    for idx, site in enumerate(urls, 1):
        print(f"[{idx}/{len(urls)}] Processing: {site}")
        logo_url, note = find_logo(driver, site)
        
        final_data.append({
            "Website URL": site,
            "Logo URL": logo_url,
            "Status/Reason": note
        })

    # Save Results
    output_df = pd.DataFrame(final_data)
    output_df.to_csv(OUTPUT_FILE, index=False)
    driver.quit()
    print(f"✅ Kaam khatam! File saved as: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()