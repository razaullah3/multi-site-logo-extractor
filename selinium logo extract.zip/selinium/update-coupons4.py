import time
import json
import os
import csv
import pandas as pd
from urllib.parse import urljoin
import undetected_chromedriver as uc # Sabse zaroori cheez
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException

# --- CONFIGURATION ---
INPUT_FILE = r"E:\web scraping data\from combine 1 to 130.xlsx"
OUTPUT_FILE = r"from combine 1 to 130 csv.csv"
HEADLESS_MODE = False  # Isko False hi rehne dein taaki security bypass ho sake

def get_driver():
    options = uc.ChromeOptions()
    if HEADLESS_MODE:
        options.add_argument("--headless")
    
    # Anti-detection profile
    driver = uc.Chrome(options=options)
    driver.set_page_load_timeout(45)
    return driver

def extract_logo_logic(driver, base_url):
    """Har us jagah se logo nikalo jahan chupa ho sakta hai."""
    
    # 1. Image Search (Sabse zyada mehnat yahan)
    images = driver.find_elements(By.TAG_NAME, "img")
    for img in images:
        try:
            # Logo ke liye keywords check karein
            alt = (img.get_attribute('alt') or '').lower()
            cls = (img.get_attribute('class') or '').lower()
            ids = (img.get_attribute('id') or '').lower()
            
            if any(key in alt or key in cls or key in ids for key in ['logo', 'brand', 'nav']):
                # Ab is image ka real URL nikaalo
                for attr in ['src', 'srcset', 'data-src', 'data-lazy-src', 'data-original']:
                    val = img.get_attribute(attr)
                    if val:
                        clean_url = val.split(',')[0].split(' ')[0].strip()
                        if "data:image" not in clean_url:
                            return urljoin(base_url, clean_url), f"Image ({attr})"
        except: continue

    # 2. JSON-LD (Professional Metadata)
    try:
        scripts = driver.find_elements(By.CSS_SELECTOR, "script[type='application/ld+json']")
        for script in scripts:
            data = json.loads(script.get_attribute("innerHTML"))
            nodes = data if isinstance(data, list) else [data]
            for node in nodes:
                graph = node.get("@graph", [node]) if isinstance(node, dict) else [node]
                for item in graph:
                    if "logo" in item:
                        res = item["logo"]["url"] if isinstance(item["logo"], dict) else item["logo"]
                        return urljoin(base_url, res), "JSON-LD"
    except: pass

    # 3. Meta Tag (Social Media Logo)
    try:
        meta = driver.find_element(By.CSS_SELECTOR, "meta[property='og:image']").get_attribute("content")
        if meta: return urljoin(base_url, meta), "Meta OG"
    except: pass

    return None, "Not Detected"

def main():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Input file nahi mili: {INPUT_FILE}")
        return
    
    df_in = pd.read_excel(INPUT_FILE, header=None)
    urls = df_in[0].dropna().unique().tolist()
    
    file_exists = os.path.isfile(OUTPUT_FILE)
    processed_urls = set()
    if file_exists:
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader: processed_urls.add(row["Website URL"])

    driver = get_driver()
    print("🚀 UNBLOCKABLE SCRAPER START...")

    try:
        with open(OUTPUT_FILE, 'a', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=["Website URL", "Logo URL", "Method", "Timestamp"])
            if not file_exists: writer.writeheader()

            for count, url in enumerate(urls, 1):
                if url in processed_urls: continue
                
                print(f"🔍 [{count}/{len(urls)}] Target: {url}")
                try:
                    driver.get(url)
                    # Site ko load hone ka poora time dein (Security bypass ke liye zaroori hai)
                    time.sleep(6) 
                    
                    # Scroll karein taaki lazy images load hon
                    driver.execute_script("window.scrollTo(0, 300);")
                    time.sleep(2)
                    
                    logo_url, method = extract_logo_logic(driver, url)
                except Exception as e:
                    logo_url, method = "N/A", f"Error: {str(e)[:15]}"

                writer.writerow({
                    "Website URL": url, 
                    "Logo URL": logo_url if logo_url else "Not Found",
                    "Method": method, 
                    "Timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                })
                f.flush()
                print(f"   {'✅' if logo_url else '❌'} Result: {method}")

    finally:
        driver.quit()
        print("✨ Task Finished.")

if __name__ == "__main__":
    main()