import time
import json
import os
import csv
import pandas as pd
from urllib.parse import urljoin
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException

# --- CONFIGURATION ---
INPUT_FILE = r"E:\web scraping data\from coombine cupons 3339 to 3370.xlsx"
OUTPUT_FILE = r"from coombine cupons 3339 to 3370.csv"
RESTART_DRIVER_EVERY = 30  # Har 30 sites baad driver fresh karega

def get_driver():
    options = uc.ChromeOptions()
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-popup-blocking")
    # Anti-detection profile to mimic real human
    driver = uc.Chrome(options=options)
    driver.set_page_load_timeout(50)
    return driver

def is_garbage(url, alt, cls):
    """Mature filter: Reject Cookie, Privacy, and Social icons."""
    blacklist = [
        'cookie', 'onetrust', 'consent', 'trustarc', 'feedback', 'social', 
        'facebook', 'twitter', 'instagram', 'paypal', 'visa', 'mastercard', 
        'payment', 'icon', 'arrow', 'banner', 'button', 'loading', 'sprite',
        'privacy', 'choices', 'adchoice'
    ]
    text_to_check = f"{url} {alt} {cls}".lower()
    return any(word in text_to_check for word in blacklist)

def extract_logo_mature(driver, base_url):
    """Multi-layer brand asset extraction."""
    
    # LAYER 1: Schema.org JSON-LD (Official Method)
    try:
        scripts = driver.find_elements(By.CSS_SELECTOR, "script[type='application/ld+json']")
        for script in scripts:
            try:
                data = json.loads(script.get_attribute("innerHTML"))
                nodes = data if isinstance(data, list) else [data]
                for node in nodes:
                    items = node.get("@graph", [node]) if isinstance(node, dict) else [node]
                    for item in items:
                        if "logo" in item:
                            res = item["logo"]["url"] if isinstance(item["logo"], dict) else item["logo"]
                            if not is_garbage(res, "", ""):
                                return urljoin(base_url, res), "Official JSON-LD"
            except: continue
    except: pass

    # LAYER 2: Image Analysis (Strict Filtering)
    try:
        images = driver.find_elements(By.TAG_NAME, "img")
        for img in images:
            src = img.get_attribute('src')
            if not src or "data:image" in src: continue
            
            alt = (img.get_attribute('alt') or '').lower()
            cls = (img.get_attribute('class') or '').lower()
            
            # Reject garbage links first
            if is_garbage(src, alt, cls): continue
            
            # Check for Logo indicators
            if any(k in alt or k in cls or k in src.lower() for k in ['logo', 'brand', 'header-main', 'navbar-brand']):
                # Ignore very small images (Mature logic)
                width = img.get_attribute('naturalWidth')
                if width and int(width) < 50: continue
                
                return urljoin(base_url, src), "Verified Brand Image"
    except: pass

    # LAYER 3: Meta Image Fallback
    try:
        og_img = driver.find_element(By.CSS_SELECTOR, "meta[property='og:image']").get_attribute("content")
        if og_img and not is_garbage(og_img, "", ""):
            return urljoin(base_url, og_img), "Meta OG Asset"
    except: pass

    return None, "Not Found"

def main():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Input file not found: {INPUT_FILE}")
        return

    # Load all URLs - UNIQUE filter removed to ensure 130 count
    df_in = pd.read_excel(INPUT_FILE, header=None)
    urls = df_in[0].dropna().astype(str).tolist()
    
    print(f"🔥 Mature Scraper Active. Total URLs: {len(urls)}")
    
    file_exists = os.path.isfile(OUTPUT_FILE)
    driver = get_driver()

    try:
        with open(OUTPUT_FILE, 'a', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=["Website URL", "Logo URL", "Method", "Timestamp"])
            if not file_exists: writer.writeheader()

            for count, url in enumerate(urls, 1):
                print(f"🔍 [{count}/{len(urls)}] Target: {url}")
                
                logo_url, method = "Not Found", "Scan Complete"
                
                try:
                    driver.get(url)
                    # Time for security bypass and full render
                    time.sleep(8) 
                    
                    # Mature Scrolling
                    driver.execute_script("window.scrollTo(0, 300);")
                    time.sleep(2)
                    
                    logo_url_res, method_res = extract_logo_mature(driver, url)
                    if logo_url_res:
                        logo_url, method = logo_url_res, method_res
                except Exception as e:
                    method = f"Error: {str(e)[:15]}"
                    if "session" in str(e).lower():
                        driver.quit()
                        driver = get_driver()

                # MANDATORY WRITING - Isse count 130 hi rahega
                writer.writerow({
                    "Website URL": url,
                    "Logo URL": logo_url,
                    "Method": method,
                    "Timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                })
                f.flush()
                print(f"   {'✅' if logo_url != 'Not Found' else '❌'} {method}")

                # RAM Management
                if count % RESTART_DRIVER_EVERY == 0:
                    driver.quit()
                    driver = get_driver()

    finally:
        driver.quit()
        print(f"✨ Task finished. Results saved in {OUTPUT_FILE}")

if __name__ == "__main__":
    main()